﻿namespace ReadIt.Models
{
  public class HttpPostedFileBase
  {
  }
}